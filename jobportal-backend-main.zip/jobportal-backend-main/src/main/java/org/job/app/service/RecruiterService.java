package org.job.app.service;

public interface RecruiterService {

}

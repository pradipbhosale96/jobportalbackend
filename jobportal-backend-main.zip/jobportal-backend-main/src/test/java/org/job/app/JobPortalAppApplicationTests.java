package org.job.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
